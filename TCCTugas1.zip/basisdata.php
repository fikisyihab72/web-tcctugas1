<?php 
$koneksi = mysqli_connect("localhost","id12509149_tugas1","tcc123","id12509149_tcctugas1db");
 
// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}
 
?>